var searchData=
[
  ['tick',['tick',['../classAdafruit__mp3.html#a9a1baa4861d222fa29f9020b945b8e97',1,'Adafruit_mp3']]]
];
